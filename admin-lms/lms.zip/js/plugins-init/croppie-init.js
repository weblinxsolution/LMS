(function($) {
    "use strict"

    



})(jQuery);