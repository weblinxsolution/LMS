(function($) {
    "use strict"



    var elem1 = $('.js-switch-1');
    new Switchery(elem1[0], {
        color: '#FF5275', 
        secondaryColor: '#FF5275' 
    });



    
})(jQuery);